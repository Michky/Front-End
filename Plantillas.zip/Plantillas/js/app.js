
(function(angular){
'use strict';
	angular.module('tesisApp',['ngRoute'])
  .config(["$routeProvider", "$locationProvider", function($routeProvider, $locationProvider){
    $routeProvider
       .when('/agregar', {
        templateUrl: 'Plantillas/agregar.html',
        controller: 'agregarCtrl'
        })
      /*.when('/confirmar', {
        templateUrl: 'Plantillas/confirmar.html'        
        })*/
      .when('/enviar', {
        templateUrl: 'Plantillas/enviarInvitacion.html'        
        })
      .when('/gestionar', {
        templateUrl: 'Plantillas/gestionarEvaluadores.html'       
        })
      .when ("/presentar",{
        templateUrl: "Plantillas/presentarPropuesta.html"
      })
      .when ("/radicar",{
        templateUrl: "Plantillas/radicar.html"
      })
      .otherwise({
      	redirectYo:'/'
      });
     $locationProvider.html5Mode(true);
    }])

  .controller("agregarCtrl", ["$scope", function($scope){
    $scope.tipo="";
    $scope.usuario = {
    nombre:"",
    apellido:"",
    id:"",
    nombre:"",
    tipo:"",
    contraseña:""
    };
    /*$scope.esEstudiante= function() {
      return (tipo == "Estudiante")
    };
    $scope.esEvaluador = function() {
      return (tipo == "Evaluador")
    };
    $scope.esProfesor = function() {
      return (tipo == "Profesor")
    };
    $scope.esAsesor= function() {
      return (tipo == "Asesor")
    };*/

  }])

  .controller('MainCtrl',["$scope",function($scope){
    $scope.botones={
      prueba:[{
        nombre: "Agregar Usuario",
        url:"/agregar"
      },{
        nombre: "Radicar Propuesta",
        url:"/radicar"
      }, {
        nombre: "Confirmar Invitaciones",
        url:"/confirmar"
      },{
      	nombre: "Enviar Invitaciones",
        url:"/enviar"
      },{
      	nombre: "Gestionar Evaluadores",
        url:"/gestionar"
      },{
      	nombre: "Presentar Propuesta",
        url:"/presentar"
      }],
      estudiante:[{
        nombre: "Presentar Propuesta",
        url:"/presentar"
      },{
        nombre: "Radicar Propuesta",
        url:"/radicar"
      },{
        nombre: "Radicar Propuesta",
        url:"/radicar"
      }],
      calificador:[]
      };
  }])
  })(window.angular);

