require('./angular-route.js');
module.exports = 'ngRoute';
